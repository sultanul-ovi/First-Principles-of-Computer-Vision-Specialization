# First-Principles-of-Computer-Vision
This repo will have implementations of some of the ideas in the coursera specialization [First Principles of Computer Vision](https://www.coursera.org/specializations/firstprinciplesofcomputervision "specialization Homepage")
